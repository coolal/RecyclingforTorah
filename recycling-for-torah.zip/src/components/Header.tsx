import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../App';

const Logo = () => (
    <div className="flex items-center gap-3">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary" fill="currentColor" viewBox="0 0 256 256">
            <path d="M232,96a8,8,0,0,0-8,8v24.38l-29-25.13a8,8,0,0,0-11.22,10.54L208.5,144H160a8,8,0,0,0,0,16h56a8,8,0,0,0,5.66-2.34,8,8,0,0,0,1.57-6.21L216,128l20.4,17.66A8,8,0,0,0,244,144a8,8,0,0,0,4-7.15V104A8,8,0,0,0,232,96ZM155.8,52.1,128,29.33,100.2,52.1a8,8,0,1,0,10.54,11.22L120,55.49V104a8,8,0,0,0,16,0V55.49l9.26,7.83a8,8,0,1,0,10.54-11.22ZM96,160H40a8,8,0,0,0-5.66,2.34,8,8,0,0,0-1.57,6.21L40,192,19.6,174.34a8,8,0,0,0-11.22,10.54L41,208.27V232a8,8,0,0,0,16,0V208.5l24.72,21.41a8,8,0,0,0,11.22-10.54L69.5,192H112a8,8,0,0,0,0-16Z"></path>
        </svg>
        <span className="text-2xl font-bold text-primary whitespace-nowrap">Recycling for Torah</span>
    </div>
);

const Header: React.FC = () => {
  const { isLoggedIn, isAdmin, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const activeLinkStyle = {
    color: '#16a34a', // primary color
    textDecoration: 'underline',
  };

  return (
    <header className="bg-white shadow-md">
      <nav className="container mx-auto px-4 md:px-8 py-4 flex justify-between items-center">
        <NavLink to="/">
          <Logo />
        </NavLink>
        <div className="flex items-center space-x-4">
          {isLoggedIn ? (
            <>
              <NavLink to="/" className="text-secondary hover:text-primary transition" style={({ isActive }) => (isActive ? activeLinkStyle : {})}>
                Request Pickup
              </NavLink>
              {isAdmin && (
                <NavLink to="/admin" className="text-secondary hover:text-primary transition" style={({ isActive }) => (isActive ? activeLinkStyle : {})}>
                  Admin Dashboard
                </NavLink>
              )}
              <button
                onClick={handleLogout}
                className="bg-secondary hover:bg-slate-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300"
              >
                Log Out
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" className="text-secondary hover:text-primary transition" style={({ isActive }) => (isActive ? activeLinkStyle : {})}>
                Sign In
              </NavLink>
              <NavLink to="/signup" className="bg-primary hover:bg-primary-hover text-white font-bold py-2 px-4 rounded-lg transition duration-300">
                Sign Up
              </NavLink>
            </>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;
