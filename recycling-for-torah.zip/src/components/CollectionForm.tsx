import React, { useState } from 'react';
import type { Submission } from '../types';
import { ICONS } from '../constants';

interface CollectionFormProps {
  addSubmission: (submission: Omit<Submission, 'id' | 'timestamp' | 'status'>) => void;
}

const InputField: React.FC<{
  id: string;
  label: string;
  type?: string;
  value: string | number;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  icon: React.ReactNode;
  required?: boolean;
  children?: React.ReactNode;
}> = ({ id, label, type = "text", value, onChange, icon, required = true, children }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <div className="relative rounded-md shadow-sm">
            <div className="pointer-events-none absolute inset-y-0 left-0 pl-3 flex items-center">
                {icon}
            </div>
            {children ? (
                <select id={id} name={id} value={value} onChange={onChange} required={required} className="block w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary appearance-none">
                    {children}
                </select>
            ) : (
                <input type={type} id={id} name={id} value={value} onChange={onChange} required={required} className="block w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary" />
            )}
        </div>
    </div>
);


const CollectionForm: React.FC<CollectionFormProps> = ({ addSubmission }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    bagsCount: 1,
    bagsLocation: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'bagsCount' ? parseInt(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addSubmission(formData);
    setSubmitted(true);
  };
  
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(formData.address)}`;

  if (submitted) {
    return (
      <div className="bg-white p-8 rounded-xl shadow-lg text-center max-w-lg mx-auto">
        <h2 className="text-3xl font-bold text-primary mb-4">Thank You!</h2>
        <p className="text-gray-700 mb-6">Your pickup request has been scheduled. We'll be there soon!</p>
        <button
          onClick={() => {
            setSubmitted(false);
            setFormData({ name: '', email: '', phone: '', address: '', bagsCount: 1, bagsLocation: '' });
          }}
          className="w-full py-3 text-lg font-bold text-white bg-primary rounded-lg hover:bg-primary-hover transition duration-300"
        >
          Schedule Another Pickup
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl shadow-lg">
      <h1 className="text-3xl font-bold text-gray-800 mb-2">Schedule a Pickup</h1>
      <p className="text-secondary mb-8">Fill out the form below to have your bottles collected.</p>
      <form onSubmit={handleSubmit} className="space-y-6">
        <InputField id="name" label="Full Name" value={formData.name} onChange={handleChange} icon={ICONS.USER} />
        <InputField id="email" label="Email Address" type="email" value={formData.email} onChange={handleChange} icon={ICONS.EMAIL} />
        <InputField id="phone" label="Phone Number" type="tel" value={formData.phone} onChange={handleChange} icon={ICONS.PHONE} />
        <div>
           <InputField id="address" label="Full Address" value={formData.address} onChange={handleChange} icon={ICONS.ADDRESS} />
           {formData.address && (
              <a href={googleMapsUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline mt-1 inline-block">
                Open in Google Maps
              </a>
            )}
        </div>
        <InputField id="bagsCount" label="Number of Bags" value={formData.bagsCount} onChange={handleChange} icon={ICONS.BAG}>
            <option disabled>Select number of bags</option>
            {Array.from({ length: 20 }, (_, i) => i + 1).map(num => (
                <option key={num} value={num}>{num}</option>
            ))}
        </InputField>
        <InputField id="bagsLocation" label="Location of Bags (e.g., 'front porch')" value={formData.bagsLocation} onChange={handleChange} icon={ICONS.LOCATION} />
        <button type="submit" className="w-full py-3 text-lg font-bold text-white bg-primary rounded-lg hover:bg-primary-hover transition duration-300">
          Request Pickup
        </button>
      </form>
    </div>
  );
};

export default CollectionForm;
