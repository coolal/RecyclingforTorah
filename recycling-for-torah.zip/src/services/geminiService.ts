
import { GoogleGenAI } from "@google/genai";
import type { Submission } from '../types';

export const generateOptimalRoute = async (submissions: Submission[], startPoint: string): Promise<string[]> => {
  const apiKey = localStorage.getItem('geminiApiKey');
  if (!apiKey) {
    throw new Error("API Key not found. Please set it in the Admin Dashboard settings.");
  }

  const ai = new GoogleGenAI({ apiKey });

  if (submissions.length === 0) {
    return [];
  }

  const addresses = submissions.map(s => s.address).join('\n');
  const prompt = `
    You are a logistics and routing expert for a recycling company.
    Your task is to create the most efficient pickup route for a driver.

    The driver will start at: ${startPoint}
    
    Here is the list of pickup addresses for today:
    ${addresses}

    Please provide the list of addresses in the most optimal order to minimize travel time and distance.
    The list should only contain the addresses, each on a new line. Do not add any extra text, numbers, or explanations. The starting point should not be in the output list.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const text = response.text;
    const orderedAddresses = text.trim().split('\n').map(addr => addr.trim()).filter(addr => addr.length > 0);

    // Basic validation to ensure the output looks like a list of addresses
    if (orderedAddresses.length > 0 && orderedAddresses[0].length > 5) {
      return orderedAddresses;
    } else {
       throw new Error("Failed to parse a valid route from the AI response.");
    }

  } catch (error) {
    console.error("Error generating optimal route:", error);
    // Fallback to original order on error
    throw new Error(`Failed to generate route from AI. Please check your API key and network. Details: ${error instanceof Error ? error.message : String(error)}`);
  }
};
