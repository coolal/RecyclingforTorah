
import React, { useState, useEffect } from 'react';
import type { Submission, AdminCredentials } from '../types';
import { generateOptimalRoute } from '../services/geminiService';
import { ICONS } from '../constants';
import { useAuth } from '../App';

const STATUS_STYLES: { [key in Submission['status']]: string } = {
    Pending: 'bg-yellow-100 text-yellow-800',
    'On The Way': 'bg-blue-100 text-blue-800',
    Completed: 'bg-green-100 text-green-800',
};

const StatusBadge: React.FC<{ status: Submission['status'] }> = ({ status }) => (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${STATUS_STYLES[status]}`}>
        {status}
    </span>
);

interface SubmissionCardProps {
    submission: Submission;
    onUpdateStatus: (id: number, status: Submission['status']) => void;
    onDelete: (id: number) => void;
}

const SubmissionCard: React.FC<SubmissionCardProps> = ({ submission, onUpdateStatus, onDelete }) => {
    const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(submission.address)}`;
    
    const handleNotifyOnTheWay = () => {
        alert(`Notification sent to ${submission.email} and ${submission.phone}:\n\n"Your Recycling for Torah pickup is on the way!"`);
        onUpdateStatus(submission.id, 'On The Way');
    };

    const handleMarkAsCollected = () => {
        alert(`Notification sent to ${submission.email} and ${submission.phone}:\n\n"Your bags have been collected. Thank you for using Recycling for Torah!"`);
        onUpdateStatus(submission.id, 'Completed');
    };

    const handleDelete = () => {
        if (window.confirm(`Are you sure you want to delete the pickup for ${submission.name}?`)) {
            onDelete(submission.id);
        }
    };

    return (
        <div className="bg-white p-4 rounded-lg shadow flex flex-col justify-between transition hover:shadow-md h-full relative">
            <button onClick={handleDelete} className="absolute top-2 right-2 p-1 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-100 transition-colors z-10" aria-label="Delete submission">
                {ICONS.TRASH}
            </button>
            <div>
                <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-lg text-gray-800 pr-8">{submission.name}</h3>
                    <StatusBadge status={submission.status} />
                </div>
                <div className="space-y-2 text-sm text-secondary">
                    <p className="flex items-center gap-2">{ICONS.EMAIL} {submission.email}</p>
                    <p className="flex items-center gap-2">{ICONS.PHONE} {submission.phone}</p>
                    <a href={googleMapsUrl} target="_blank" rel="noopener noreferrer" className="hover:text-primary hover:underline flex items-center gap-2">
                        {ICONS.ADDRESS} <span className="flex-1">{submission.address}</span>
                    </a>
                </div>
                <div className="mt-3 flex justify-between items-center bg-light p-2 rounded-md text-sm">
                    <div className="flex items-center gap-2">
                        {ICONS.BAG}
                        <span>{submission.bagsCount} bag(s)</span>
                    </div>
                    <div className="flex items-center gap-2 text-right">
                        {ICONS.LOCATION}
                        <span>{submission.bagsLocation}</span>
                    </div>
                </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
                <button 
                    onClick={handleNotifyOnTheWay}
                    disabled={submission.status !== 'Pending'}
                    className="w-full px-3 py-2 text-xs font-bold text-white bg-blue-500 rounded-md hover:bg-blue-600 transition duration-300 disabled:bg-gray-300 disabled:cursor-not-allowed">
                    Notify: On The Way
                </button>
                 <button 
                    onClick={handleMarkAsCollected}
                    disabled={submission.status !== 'On The Way'}
                    className="w-full px-3 py-2 text-xs font-bold text-white bg-green-500 rounded-md hover:bg-green-600 transition duration-300 disabled:bg-gray-300 disabled:cursor-not-allowed">
                    Mark as Collected
                </button>
            </div>
        </div>
    );
};

const AdminSettings: React.FC<{
    adminCredentials: AdminCredentials;
    setAdminCredentials: (creds: AdminCredentials) => void;
}> = ({ adminCredentials, setAdminCredentials }) => {
    const { logout } = useAuth();
    const [email, setEmail] = useState(adminCredentials.email);
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        if (!email.trim() || !password.trim()) {
            alert('Email and password cannot be empty.');
            return;
        }
        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }
        if (window.confirm("Are you sure you want to update the admin credentials? You will be logged out and need to sign in again.")) {
            setAdminCredentials({ email, password });
            alert("Credentials updated successfully.");
            logout();
        }
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-lg mb-8">
            <h2 className="text-xl font-bold text-gray-800 mb-2">Admin Settings</h2>
            <p className="text-sm text-gray-500 mb-4">Update the login credentials for the admin account.</p>
            <form onSubmit={handleSave} className="space-y-4 max-w-md">
                 <div>
                    <label htmlFor="adminEmail" className="block text-sm font-medium text-gray-700 mb-1">Admin Email</label>
                    <input
                        type="email"
                        id="adminEmail"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="block w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                        placeholder="New admin email"
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="adminPassword" className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                    <input
                        type="password"
                        id="adminPassword"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="block w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                        placeholder="Enter new password"
                        required
                    />
                </div>
                 <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                    <input
                        type="password"
                        id="confirmPassword"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="block w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                        placeholder="Confirm new password"
                        required
                    />
                </div>
                <button
                    type="submit"
                    className="px-5 py-2 text-base font-bold text-white bg-secondary rounded-lg hover:bg-slate-700 transition duration-300"
                >
                    Save & Log Out
                </button>
            </form>
        </div>
    );
};

const ApiKeyManager: React.FC<{ apiKey: string; setApiKey: (key: string) => void; isKeySaved: boolean; setIsKeySaved: (saved: boolean) => void; }> = 
({ apiKey, setApiKey, isKeySaved, setIsKeySaved }) => {
    
    const handleSaveKey = () => {
        if (!apiKey.trim()) {
            alert('API Key cannot be empty.');
            return;
        }
        localStorage.setItem('geminiApiKey', apiKey);
        setIsKeySaved(true);
        alert('API Key saved successfully.');
    };

    return (
        <div className="space-y-4">
            <div>
                <label htmlFor="apiKey" className="block text-sm font-medium text-gray-700 mb-1">Gemini API Key</label>
                <div className="flex items-center gap-2">
                    <input
                        type="password"
                        id="apiKey"
                        value={apiKey}
                        onChange={(e) => {
                            setApiKey(e.target.value);
                            setIsKeySaved(false);
                        }}
                        className="block w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                        placeholder="Enter your Gemini API Key"
                    />
                    <button onClick={handleSaveKey} className="px-5 py-2 text-base font-bold text-white bg-secondary rounded-lg hover:bg-slate-700 transition duration-300">
                        Save Key
                    </button>
                </div>
                {isKeySaved && <p className="text-sm text-green-600 mt-1">API Key is saved in this browser.</p>}
            </div>
        </div>
    );
};


const AdminDashboard: React.FC<{
    submissions: Submission[];
    setSubmissions: React.Dispatch<React.SetStateAction<Submission[]>>;
    deleteSubmission: (id: number) => void;
    adminCredentials: AdminCredentials;
    setAdminCredentials: (creds: AdminCredentials) => void;
}> = ({ submissions, setSubmissions, deleteSubmission, adminCredentials, setAdminCredentials }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [startPoint, setStartPoint] = useState('100 Recycling Way, Green City, USA');
    const [apiKey, setApiKey] = useState(() => localStorage.getItem('geminiApiKey') || '');
    const [isKeySaved, setIsKeySaved] = useState(() => !!localStorage.getItem('geminiApiKey'));
    
    useEffect(() => {
        setIsKeySaved(!!localStorage.getItem('geminiApiKey'));
    }, [apiKey]);


    const handleUpdateStatus = (submissionId: number, newStatus: Submission['status']) => {
        setSubmissions(currentSubmissions => 
            currentSubmissions.map(sub => 
                sub.id === submissionId ? { ...sub, status: newStatus } : sub
            )
        );
    };
    
    const handleClearAll = () => {
        if (window.confirm(`Are you sure you want to delete all ${submissions.length} pickup requests? This action cannot be undone.`)) {
            setSubmissions([]);
        }
    };

    const handleOptimizeRoute = async () => {
        setIsLoading(true);
        setError(null);
        try {
            // We only want to route pending submissions
            const pendingSubmissions = submissions.filter(s => s.status === 'Pending');
            if (pendingSubmissions.length < 2) {
                setError("At least 2 'Pending' submissions are needed to optimize a route.");
                setIsLoading(false);
                return;
            }

            const orderedAddresses = await generateOptimalRoute(pendingSubmissions, startPoint);
            const submissionMap = new Map(pendingSubmissions.map(s => [s.address, s]));
            
            const orderedPending = orderedAddresses
                .map(address => submissionMap.get(address))
                .filter((s): s is Submission => s !== undefined);
            
            const unroutablePending = pendingSubmissions.filter(s => !orderedAddresses.includes(s.address));
            const otherSubmissions = submissions.filter(s => s.status !== 'Pending');

            setSubmissions([...orderedPending, ...unroutablePending, ...otherSubmissions]);

        } catch (e: any) {
            setError(e.message || "An unexpected error occurred.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const pendingCount = submissions.filter(s => s.status === 'Pending').length;

    return (
        <div className="max-w-7xl mx-auto">
            <h1 className="text-3xl font-bold text-gray-800 mb-6">Admin Dashboard</h1>

            <AdminSettings adminCredentials={adminCredentials} setAdminCredentials={setAdminCredentials} />
            
            <div className="bg-white p-6 rounded-xl shadow-lg mb-8">
                <h2 className="text-xl font-bold text-gray-800 mb-4">Route Optimization & API</h2>
                 <ApiKeyManager apiKey={apiKey} setApiKey={setApiKey} isKeySaved={isKeySaved} setIsKeySaved={setIsKeySaved} />

                <div className="mt-6 border-t pt-6">
                    <div className="flex flex-col md:flex-row items-center gap-4">
                        <div className="w-full md:flex-1">
                             <label htmlFor="startPoint" className="block text-sm font-medium text-gray-700 mb-1">Depot / Starting Point</label>
                             <input
                                type="text"
                                id="startPoint"
                                value={startPoint}
                                onChange={(e) => setStartPoint(e.target.value)}
                                className="block w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
                                placeholder="Enter starting address"
                            />
                        </div>
                        <button
                            onClick={handleOptimizeRoute}
                            disabled={isLoading || pendingCount < 2 || !isKeySaved}
                            className="w-full md:w-auto flex items-center justify-center px-6 py-2.5 text-base font-bold text-white bg-primary rounded-lg hover:bg-primary-hover transition duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed"
                        >
                            {isLoading && ICONS.SPINNER}
                            {isLoading ? 'Optimizing...' : 'Generate Optimal Route'}
                        </button>
                    </div>
                </div>
                 {!isKeySaved && <p className="text-red-500 mt-2 text-sm">Please save your Gemini API Key above to enable route optimization.</p>}
                 {error && <p className="text-red-500 mt-2 text-sm">{error}</p>}
                <p className="text-sm text-gray-500 mt-2">
                    {pendingCount < 2 ? `At least 2 'Pending' submissions are needed to optimize a route. You have ${pendingCount}.` : `Optimizes the route for all ${pendingCount} pending submissions.`}
                </p>

                <div className="mt-6 border-t pt-4">
                  <h3 className="text-lg font-semibold text-red-800 mb-2">Danger Zone</h3>
                  <button
                    onClick={handleClearAll}
                    disabled={submissions.length === 0}
                    className="flex items-center justify-center gap-2 px-4 py-2 text-sm font-bold text-white bg-red-600 rounded-lg hover:bg-red-700 transition duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {ICONS.TRASH}
                    Delete All Pickups ({submissions.length})
                  </button>
                </div>
            </div>

            <h2 className="text-2xl font-bold text-gray-800 mb-4">Pickup Queue ({submissions.length})</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {submissions.length > 0 ? (
                    submissions.map((sub, index) => (
                        <div key={sub.id} className="relative">
                            <span className="absolute -top-2 -left-2 bg-primary text-white rounded-full h-8 w-8 flex items-center justify-center font-bold text-sm shadow-lg z-10">{index + 1}</span>
                            <SubmissionCard submission={sub} onUpdateStatus={handleUpdateStatus} onDelete={deleteSubmission} />
                        </div>
                    ))
                ) : (
                    <p className="text-secondary col-span-full text-center py-8">No pickup requests yet.</p>
                )}
            </div>
        </div>
    );
};

export default AdminDashboard;
